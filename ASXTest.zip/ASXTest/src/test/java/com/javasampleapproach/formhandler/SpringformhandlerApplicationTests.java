package com.javasampleapproach.formhandler;

import org.junit.Test;
import org.junit.runner.RunWith;


public class SpringformhandlerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
