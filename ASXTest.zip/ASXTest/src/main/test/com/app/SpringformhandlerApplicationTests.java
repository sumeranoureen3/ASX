package com.app;

import static org.junit.Assert.*;

import org.junit.Test;

public class SpringformhandlerApplicationTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
